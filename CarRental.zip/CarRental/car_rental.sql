-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Εξυπηρετητής: 127.0.0.1
-- Χρόνος δημιουργίας: 16 Νοε 2023 στις 17:24:05
-- Έκδοση διακομιστή: 10.4.27-MariaDB
-- Έκδοση PHP: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Βάση δεδομένων: `car_rental`
--

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `car`
--

CREATE TABLE `car` (
  `Car_Id` int(30) NOT NULL,
  `Category` int(30) NOT NULL,
  `Model` varchar(30) NOT NULL,
  `CC` int(30) NOT NULL,
  `CostPerDay` double NOT NULL,
  `Seats` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Άδειασμα δεδομένων του πίνακα `car`
--

INSERT INTO `car` (`Car_Id`, `Category`, `Model`, `CC`, `CostPerDay`, `Seats`) VALUES
(1, 1, 'Toyota Yaris', 1300, 15, 5),
(2, 1, 'Opel Corsa', 1300, 17, 5),
(3, 2, 'Hyundai I30', 1600, 30, 5),
(4, 2, 'Seat Leon', 1600, 38, 5),
(5, 3, 'Mercedes E220', 2000, 70, 5),
(6, 3, 'Tesla Model 3 Standar Plus', 2000, 85, 5),
(7, 4, 'Pagani Huaya', 6000, 500, 2),
(8, 4, 'Ferrari LaFerrari', 6000, 750, 2);

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `car_category`
--

CREATE TABLE `car_category` (
  `Id` int(30) NOT NULL,
  `Cat_Name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Άδειασμα δεδομένων του πίνακα `car_category`
--

INSERT INTO `car_category` (`Id`, `Cat_Name`) VALUES
(1, 'Mikra'),
(2, 'Mesaia '),
(3, 'Megala'),
(4, 'Politeli');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `car_rent`
--

CREATE TABLE `car_rent` (
  `Rental_Id` int(30) NOT NULL,
  `Customer_Id` int(30) NOT NULL,
  `Car_Id` int(30) NOT NULL,
  `Days` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Άδειασμα δεδομένων του πίνακα `car_rent`
--

INSERT INTO `car_rent` (`Rental_Id`, `Customer_Id`, `Car_Id`, `Days`) VALUES
(1, 1, 7, 5),
(2, 2, 8, 15);

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `customer`
--

CREATE TABLE `customer` (
  `Customer_Id` int(30) NOT NULL,
  `First_Name` varchar(30) NOT NULL,
  `Last_Name` varchar(30) NOT NULL,
  `Gender` varchar(30) NOT NULL,
  `Address` varchar(30) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Phone` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Άδειασμα δεδομένων του πίνακα `customer`
--

INSERT INTO `customer` (`Customer_Id`, `First_Name`, `Last_Name`, `Gender`, `Address`, `Email`, `Phone`) VALUES
(1, 'Kostas', 'Gkotzamanis', '1', 'Kardia', 'KosGkotz@gmail.com', '+30 69442565'),
(2, 'Xristos ', 'Spyridis', '1', 'Papadiamanti 35', 'ChriSp@gmail.com', '+30 69887415');

--
-- Ευρετήρια για άχρηστους πίνακες
--

--
-- Ευρετήρια για πίνακα `car`
--
ALTER TABLE `car`
  ADD PRIMARY KEY (`Car_Id`,`Category`),
  ADD KEY `Category` (`Category`);

--
-- Ευρετήρια για πίνακα `car_category`
--
ALTER TABLE `car_category`
  ADD PRIMARY KEY (`Id`);

--
-- Ευρετήρια για πίνακα `car_rent`
--
ALTER TABLE `car_rent`
  ADD PRIMARY KEY (`Rental_Id`,`Customer_Id`,`Car_Id`),
  ADD KEY `Customer_Id` (`Customer_Id`),
  ADD KEY `Car_Id` (`Car_Id`);

--
-- Ευρετήρια για πίνακα `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`Customer_Id`);

--
-- AUTO_INCREMENT για άχρηστους πίνακες
--

--
-- AUTO_INCREMENT για πίνακα `car`
--
ALTER TABLE `car`
  MODIFY `Car_Id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT για πίνακα `car_category`
--
ALTER TABLE `car_category`
  MODIFY `Id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT για πίνακα `car_rent`
--
ALTER TABLE `car_rent`
  MODIFY `Rental_Id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT για πίνακα `customer`
--
ALTER TABLE `customer`
  MODIFY `Customer_Id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Περιορισμοί για άχρηστους πίνακες
--

--
-- Περιορισμοί για πίνακα `car`
--
ALTER TABLE `car`
  ADD CONSTRAINT `car_ibfk_1` FOREIGN KEY (`Category`) REFERENCES `car_category` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Περιορισμοί για πίνακα `car_rent`
--
ALTER TABLE `car_rent`
  ADD CONSTRAINT `car_rent_ibfk_1` FOREIGN KEY (`Customer_Id`) REFERENCES `customer` (`Customer_Id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `car_rent_ibfk_2` FOREIGN KEY (`Car_Id`) REFERENCES `car` (`Car_Id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
