import java.awt.EventQueue;
import java.sql.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.cj.xdevapi.Statement;

import javax.swing.JFrame;
import javax.swing.JTabbedPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JToggleButton;
import javax.swing.JSeparator;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.SwingConstants;

public class CarDeal {
	
	

	private JFrame frame;
	private JTextField firstNameField;
	private JTextField lastNameField;
	private JTextField emailField;
	private JTextField phoneField;
	private JTextField custidField;
	private JTextField addressField;
	private JTextField genderField;
	private JTextField totalcostField;
	private JTextField caridField;
	private JTextField daysField;
	private JTable carTable;
	private JTextField dailycostField;
	private JTable CustTable;
	private JTable delpanTable;
	private JTextField delrentalField;
	private JTextField delcustField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CarDeal window = new CarDeal();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CarDeal() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 862, 545);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(0, 10, 848, 488);
		frame.getContentPane().add(tabbedPane);
		
		int rowsAffected = 1;
		
		JPanel Cars = new JPanel();
		tabbedPane.addTab("Customers", null, Cars, null);
		Cars.setLayout(null);
		
		 DBUtils dbUtils = new DBUtils();
		 
		JButton btnShow = new JButton("Show");
		btnShow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					Connection connection = dbUtils.getConnection();
					java.sql.Statement statement = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
					ResultSet resultSet1 = statement.executeQuery("SELECT * FROM customer");
					ResultSetMetaData rsmd = resultSet1 .getMetaData();
					DefaultTableModel model = (DefaultTableModel) CustTable.getModel();
					
					int cols = rsmd.getColumnCount();
					String[] colName = new String[cols];
					for (int i=0; i<cols; i++) 
						colName[i] = rsmd.getColumnName(i+1);
					model.setColumnIdentifiers(colName);
					String Customer_Id, First_Name, Last_Name, Gender, Address, Email,  Phone;
					while(resultSet1.next()) {
						Customer_Id = resultSet1.getString(1);
						First_Name = resultSet1.getString(2);
						Last_Name = resultSet1.getString(3);
						Gender = resultSet1.getString(4);
						Address = resultSet1.getString(5);
						Email = resultSet1.getString(6);
						Phone = resultSet1.getString(7);
						 
						String[] row =  {Customer_Id, First_Name, Last_Name, Gender, Address, Email,  Phone};
						model.addRow(row);					
					}
						statement.close();
						connection.close();

		        } catch (Exception e3) {
		            e3.printStackTrace();
		        }
				
				
			}
		});
		btnShow.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnShow.setBounds(114, 405, 103, 46);
		Cars.add(btnShow);
		
		JLabel lblNewLabel_2_1_1 = new JLabel("Customers Informations");
		lblNewLabel_2_1_1.setBounds(267, -12, 324, 64);
		Cars.add(lblNewLabel_2_1_1);
		lblNewLabel_2_1_1.setFont(new Font("Tahoma", Font.PLAIN, 30));
		
		JButton btnReset = new JButton("Reset");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CustTable.setModel(new DefaultTableModel());
			}
		});
		btnReset.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnReset.setBounds(357, 405, 103, 46);
		Cars.add(btnReset);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(10, 40, 823, 307);
		Cars.add(scrollPane_1);
		
		CustTable = new JTable();
		scrollPane_1.setViewportView(CustTable);
		
		JButton delcustbtn = new JButton("Delete");
		delcustbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					DBUtils dbUtils = new DBUtils();
					int deleteCust = Integer.parseInt(delcustField.getText());
					Connection connection = dbUtils.getConnection();
					
					String deleteCustQuery = "DELETE FROM customer WHERE Customer_Id = ?";
					PreparedStatement deleteCustStmt = connection.prepareStatement(deleteCustQuery);
					deleteCustStmt.setInt(1, deleteCust);
					deleteCustStmt.executeUpdate();
					
					delcustField.setText("");
					
					connection.close();
					
					//Display Successful Message
					JOptionPane.showMessageDialog(null, "Επιτυχής Διαγραφή Πελάτη");
        		} catch (SQLException e1) {
        			JOptionPane.showMessageDialog(null, "Η Διαγραφή΄Πελάτη Απετυχε");
        			e1.printStackTrace();
        		
			}
				
			}
		});
		delcustbtn.setFont(new Font("Tahoma", Font.PLAIN, 20));
		delcustbtn.setBounds(628, 405, 103, 46);
		Cars.add(delcustbtn);
		
		JLabel lblNewLabel_2_2 = new JLabel("Customer Id:");
		lblNewLabel_2_2.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblNewLabel_2_2.setBounds(580, 368, 107, 27);
		Cars.add(lblNewLabel_2_2);
		
		delcustField = new JTextField();
		delcustField.setColumns(10);
		delcustField.setBounds(682, 369, 96, 26);
		Cars.add(delcustField);
		
		JPanel NC1 = new JPanel();
		tabbedPane.addTab("New Customer", null, NC1, null);
		NC1.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("First Name:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel.setBounds(10, 32, 99, 29);
		NC1.add(lblNewLabel);
		
		firstNameField = new JTextField();
		firstNameField.setBounds(107, 32, 125, 27);
		NC1.add(firstNameField);
		firstNameField.setColumns(10);
		
		JLabel lblLastName = new JLabel("Last Name:");
		lblLastName.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblLastName.setBounds(351, 32, 99, 29);
		NC1.add(lblLastName);
		
		lastNameField = new JTextField();
		lastNameField.setColumns(10);
		lastNameField.setBounds(500, 36, 125, 27);
		NC1.add(lastNameField);
		
		JLabel lblEmail = new JLabel("Email:");
		lblEmail.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblEmail.setBounds(351, 95, 99, 29);
		NC1.add(lblEmail);
		
		emailField = new JTextField();
		emailField.setColumns(10);
		emailField.setBounds(500, 99, 125, 27);
		NC1.add(emailField);
		
		JLabel lblPhoneNumber = new JLabel("Phone :");
		lblPhoneNumber.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblPhoneNumber.setBounds(10, 166, 99, 29);
		NC1.add(lblPhoneNumber);
		
		phoneField = new JTextField();
		phoneField.setColumns(10);
		phoneField.setBounds(107, 170, 125, 27);
		NC1.add(phoneField);
		
		JToggleButton registerButton = new JToggleButton("Register");
		registerButton.setFont(new Font("Tahoma", Font.PLAIN, 16));
		registerButton.setBounds(238, 296, 154, 44);
		NC1.add(registerButton);
		
		JLabel lblGender = new JLabel("Gender:");
		lblGender.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblGender.setBounds(10, 95, 99, 29);
		NC1.add(lblGender);
		
		addressField = new JTextField();
		addressField.setColumns(10);
		addressField.setBounds(500, 174, 125, 27);
		NC1.add(addressField);
		
		JLabel lblAddress = new JLabel("Address:");
		lblAddress.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblAddress.setBounds(351, 177, 99, 29);
		NC1.add(lblAddress);
		
		genderField = new JTextField();
		genderField.setColumns(10);
		genderField.setBounds(107, 95, 125, 27);
		NC1.add(genderField);
		
        registerButton.addActionListener(new ActionListener() {
        	
        	DBUtils dbUtils = new DBUtils();
        	
            public void actionPerformed(ActionEvent e) {
                String firstName = firstNameField.getText();
                String lastName = lastNameField.getText();
                String gender = genderField.getText();
                String address = addressField.getText();
                String email = emailField.getText();
                String phone = phoneField.getText();
                

        		try {
        			Connection connection = dbUtils.getConnection();
        			java.sql.Statement statement = connection.createStatement();        			
                    String sql = "INSERT INTO customer (First_Name, Last_Name, Gender, Address, Email, Phone) VALUES ('" + firstName + "', '" + lastName + "', '" + gender + "', '" + address + "', '" + email + "', '" + phone + "')";
                    statement.executeUpdate(sql);
                    
                    if (rowsAffected > 0) {
                        JOptionPane.showMessageDialog(null, "Η Εγγραφη πετυχε!");

                        // Καθαρισμός πεδίων μετά από επιτυχημένη εγγραφή
                        firstNameField.setText("");
                        lastNameField.setText("");
                        genderField.setText("");
                        addressField.setText("");
                        emailField.setText("");
                        phoneField.setText("");
                    } else {
                        JOptionPane.showMessageDialog(null, "Η εγγραφή απέτυχε.");
                    }


                    connection.close();

 
        		} catch (SQLException e1) {
        			e1.printStackTrace();
        		}
            }
        });
		
		JPanel panel = new JPanel();
		tabbedPane.addTab("Add Rental", null, panel, null);
		panel.setLayout(null);
		
		custidField = new JTextField();
		custidField.setBounds(103, 18, 64, 27);
		panel.add(custidField);
		custidField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Customer ID:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(10, 16, 132, 27);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Car ID:");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1_1.setBounds(171, 16, 72, 27);
		panel.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Rental Days:");
		lblNewLabel_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1_1_1.setBounds(298, 16, 86, 27);
		panel.add(lblNewLabel_1_1_1);
		
		JButton btnrent = new JButton("Rent");
		btnrent.setFont(new Font("Tahoma", Font.PLAIN, 25));
		btnrent.setBounds(282, 93, 121, 49);
		panel.add(btnrent);
		
		btnrent.addActionListener(new ActionListener() {
        	
        	DBUtils dbUtils = new DBUtils();
        	
            public void actionPerformed(ActionEvent e) {
                String custid = custidField.getText();
                String carid = caridField.getText();
                String days = daysField.getText();


        		try {
        			Connection connection = dbUtils.getConnection();
        			java.sql.Statement statement = connection.createStatement();        			
                    String sql = "INSERT INTO car_rent (Customer_Id, Car_Id,  Days ) VALUES ('" + custid + "', '" + carid + "', '" + days + "')";
                    statement.executeUpdate(sql);
                    
                    if (rowsAffected > 0) {
                        JOptionPane.showMessageDialog(null, "Η Εγγραφη πετυχε!");

                        // Καθαρισμός πεδίων μετά από επιτυχημένη εγγραφή
                        custidField.setText("");
                        caridField.setText("");
                        daysField.setText("");
                    } else {
                        JOptionPane.showMessageDialog(null, "Η εγγραφή απέτυχε.");
                    }


                    connection.close();

 
        		} catch (SQLException e1) {
        			e1.printStackTrace();
        		}
            }
		});
		
		
		
		JButton btnshowcars = new JButton("Show");
		btnshowcars.setFont(new Font("Tahoma", Font.PLAIN, 25));
		btnshowcars.setBounds(298, 402, 121, 49);
		panel.add(btnshowcars);
		
		JLabel lblNewLabel_1_2 = new JLabel("Car Informations:");
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.PLAIN, 19));
		lblNewLabel_1_2.setBounds(263, 152, 185, 27);
		panel.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("Total Cost:");
		lblNewLabel_1_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1_1_1_1.setBounds(642, 16, 80, 27);
		panel.add(lblNewLabel_1_1_1_1);
		
		totalcostField = new JTextField();
		totalcostField.setColumns(10);
		totalcostField.setBounds(732, 15, 101, 33);
		panel.add(totalcostField);
		
		caridField = new JTextField();
		caridField.setColumns(10);
		caridField.setBounds(225, 18, 74, 27);
		panel.add(caridField);
		
		daysField = new JTextField();
		daysField.setColumns(10);
		daysField.setBounds(393, 18, 64, 27);
		panel.add(daysField);
		
		JButton btnCalculate = new JButton("Calculate");
		btnCalculate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String strNum1 = daysField.getText();
				String strNum2 = dailycostField.getText();
				String strResult = "";
				
				
				try {
				double num1 = Double.valueOf(strNum1);
				double num2 = Double.valueOf(strNum2);
				double result = num1 * num2;
				strResult = String.valueOf(result);						
				
				}catch(NumberFormatException x){
					strResult = "Error";
				}
				totalcostField.setText(strResult);
				
			}
		});
		btnCalculate.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnCalculate.setBounds(684, 64, 121, 39);
		panel.add(btnCalculate);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(823, 169, -816, 226);
		panel.add(panel_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 179, 823, 220);
		panel.add(scrollPane);
		
		carTable = new JTable();
		scrollPane.setViewportView(carTable);
		
		JButton btnClear = new JButton("Clear");
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				carTable.setModel(new DefaultTableModel());
			}
		});
		btnClear.setFont(new Font("Tahoma", Font.PLAIN, 25));
		btnClear.setBounds(489, 402, 121, 49);
		panel.add(btnClear);
		
		JLabel lblNewLabel_1_1_1_2 = new JLabel("Daily Cost:");
		lblNewLabel_1_1_1_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1_1_1_2.setBounds(467, 16, 72, 27);
		panel.add(lblNewLabel_1_1_1_2);
		
		dailycostField = new JTextField();
		dailycostField.setColumns(10);
		dailycostField.setBounds(549, 18, 83, 27);
		panel.add(dailycostField);
		
		JButton btnClearCal = new JButton("Clear");
		btnClearCal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				daysField.setText(null);
				dailycostField.setText("");
				totalcostField.setText(null);
				
			}
		});
		btnClearCal.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnClearCal.setBounds(684, 113, 121, 39);
		panel.add(btnClearCal);
		
		JPanel Customers = new JPanel();
		tabbedPane.addTab("Delete Rental", null, Customers, null);
		Customers.setLayout(null);
		
		JScrollPane delpanTable1 = new JScrollPane();
		delpanTable1.setBounds(10, 10, 823, 334);
		Customers.add(delpanTable1);
		
		delpanTable = new JTable();
		delpanTable1.setViewportView(delpanTable);
		
		
		
		JButton showcustbtn = new JButton("Show");
		showcustbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					Connection connection = dbUtils.getConnection();
					java.sql.Statement statement = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
					ResultSet resultSet = statement.executeQuery("SELECT "
							+ "    c.Customer_Id, "
							+ "    c.First_Name, "
							+ "    c.Last_Name, "
							+ "    r.Rental_Id, "
							+ "    car.Model "
							+ "FROM customer c "
							+ "INNER JOIN  car_rent r ON c.Customer_Id = r.Customer_Id "
							+ "INNER JOIN car ON r.Car_Id = car.Car_Id;");
					ResultSetMetaData rsmd = resultSet.getMetaData();
					DefaultTableModel model = (DefaultTableModel) delpanTable.getModel();
					
					int cols = rsmd.getColumnCount();
					String[] colName = new String[cols];
					for (int i=0; i<cols; i++) 
						colName[i] = rsmd.getColumnName(i+1);
					model.setColumnIdentifiers(colName);
					String Customer_Id, First_Name, Last_Name,Rental_Id, Model;
					while(resultSet.next()) {
						Customer_Id = resultSet.getString(1);
						First_Name = resultSet.getString(2);
						Last_Name = resultSet.getString(3);
						Rental_Id = resultSet.getString(4);
						Model = resultSet.getString(5);
						String[] row =  {Customer_Id, First_Name, Last_Name,Rental_Id, Model};
						model.addRow(row);					
					}
						statement.close();
						connection.close();		
		        } catch (Exception e2) {
		            e2.printStackTrace();
		        }
		    
			}
		});
		showcustbtn.setFont(new Font("Tahoma", Font.PLAIN, 23));
		showcustbtn.setBounds(130, 402, 107, 38);
		Customers.add(showcustbtn);
		
		JButton btnDeleteRental = new JButton("Delete Rental");
		btnDeleteRental.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					DBUtils dbUtils = new DBUtils();
					int deleteRental = Integer.parseInt(delrentalField.getText());
					Connection connection = dbUtils.getConnection();
					
					String deleteRentalQuery = "DELETE FROM car_rent WHERE Rental_Id = ?";
					PreparedStatement deleteRentalStmt = connection.prepareStatement(deleteRentalQuery);
					deleteRentalStmt.setInt(1, deleteRental);
					deleteRentalStmt.executeUpdate();
					
					connection.close();
					
					//Display Successful Message
					JOptionPane.showMessageDialog(null, "Επιτυχής Διαγραφή Ενοικίας");
        		} catch (SQLException e1) {
        			JOptionPane.showMessageDialog(null, "Η Διαγραφή Ενοικίας Απετυχε");
        			e1.printStackTrace();
        		
			}
			}
		});
		btnDeleteRental.setFont(new Font("Tahoma", Font.PLAIN, 23));
		btnDeleteRental.setBounds(558, 402, 232, 38);
		Customers.add(btnDeleteRental);
		
		JButton clearcusbtn = new JButton("Clear");
		clearcusbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				delpanTable.setModel(new DefaultTableModel());
			}
		});
		clearcusbtn.setFont(new Font("Tahoma", Font.PLAIN, 23));
		clearcusbtn.setBounds(324, 402, 107, 38);
		Customers.add(clearcusbtn);
		
		JLabel lblNewLabel_2_1 = new JLabel("Rental Id:");
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblNewLabel_2_1.setBounds(588, 365, 107, 27);
		Customers.add(lblNewLabel_2_1);
		
		delrentalField = new JTextField();
		delrentalField.setColumns(10);
		delrentalField.setBounds(684, 366, 96, 26);
		Customers.add(delrentalField);

      btnshowcars.addActionListener(new ActionListener() {
	
	  DBUtils dbUtils = new DBUtils();
	
     public void actionPerformed(ActionEvent e) {

		
			try {
				Connection connection = dbUtils.getConnection();
				java.sql.Statement statement = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
				ResultSet resultSet = statement.executeQuery("SELECT * FROM car");
				ResultSetMetaData rsmd = resultSet.getMetaData();
				DefaultTableModel model = (DefaultTableModel) carTable.getModel();
				
				int cols = rsmd.getColumnCount();
				String[] colName = new String[cols];
				for (int i=0; i<cols; i++) 
					colName[i] = rsmd.getColumnName(i+1);
				model.setColumnIdentifiers(colName);
				String Car_Id, Category, Model, Cc, CostPerDay, Seats;
				while(resultSet.next()) {
					Car_Id = resultSet.getString(1);
					Category = resultSet.getString(2);
					Model = resultSet.getString(3);
					Cc = resultSet.getString(4);
					CostPerDay = resultSet.getString(5);
					Seats = resultSet.getString(6); 
					String[] row =  {Car_Id, Category, Model, Cc, CostPerDay, Seats};
					model.addRow(row);					
				}
					statement.close();
					connection.close();		
	        } catch (Exception e2) {
	            e2.printStackTrace();
	        }
	    
	}{}
		
				
       
		});
      
	}	
}
		

	

