import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtils {
	
	String database = "jdbc:mysql://localhost/car_rental";
	String username = "root";
	String password = "";
	
	
	public Connection getConnection() throws SQLException {
		return DriverManager.getConnection(database, username, password);
	}

}
